import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as S3Assets from 'aws-cdk-lib/aws-s3-assets';
import * as Ec2L3 from './index';



export class MyBastion extends Construct {

    public readonly myBastionhost: ec2.BastionHostLinux;
  
    constructor(scope: Construct, id: string, props: Ec2L3.Ec2L3Props) {
      super(scope, id);
  
      const userData = ec2.UserData.forLinux();
  
  //for our env
  const ec2SG = new ec2.SecurityGroup(this, 'ec2SG', {
    vpc: props.vpc,
    allowAllOutbound: true,
    description: 'security group for bastion server',
  });
  
  ec2SG.addIngressRule(
    ec2.Peer.ipv4('199.169.204.178/32'),
    ec2.Port.tcp(22)
  );
  
  ec2SG.addIngressRule(
    ec2.Peer.ipv4('199.169.204.178/32'),
    ec2.Port.tcp(80)
  );
  
  ec2SG.addIngressRule(
    ec2.Peer.ipv4('199.169.204.178/32'),
    ec2.Port.tcp(22)
  );
  
  ec2SG.addIngressRule(
    ec2.Peer.ipv4('3.83.200.219/32'),
    ec2.Port.tcp(80)
  );
  
  ec2SG.addIngressRule(
    ec2.Peer.ipv4('3.83.200.219/32'),
    ec2.Port.tcp(443)
  );
  ec2SG.addIngressRule(
    ec2.Peer.ipv4('3.83.200.219/32'),
    ec2.Port.tcp(22)
  );
  
  ec2SG.addIngressRule(
    ec2.Peer.ipv4('10.0.0.0/16'),
    ec2.Port.tcp(22)
  );
  if ('asset' in props)
  {
      const asset = new  S3Assets.Asset(this, 'S3Asset', {
        path: 'fileplace/testfile.txt'
      });
  
      
      userData.addS3DownloadCommand({
        bucket: asset.bucket,
        bucketKey: asset.s3ObjectKey,
        localFile: '/tmp/testfile.txt'
      });
  
      userData.addCommands(
        'chmod +r /tmp/testfile.txt',
        'sudo cp /tmp/testfile.txt /usr/local/bin'
      );
  
      new cdk.CfnOutput(this, 'message', {value:props.asset!, description:"in if"})
  }
  
  new cdk.CfnOutput(this, 'messag2e', {value:props.serverpath!, description:"in after if"})
  
      this.myBastionhost = new ec2.BastionHostLinux(this, 'Bastion',{
        vpc: props.vpc,
        requireImdsv2: true,
        securityGroup: ec2SG,
        machineImage: ec2.MachineImage.latestAmazonLinux({
        userData: userData,
          generation: ec2.AmazonLinuxGeneration.AMAZON_LINUX_2
        })
      });
  
      const bastaionrole = this.myBastionhost.role;
      bastaionrole.addManagedPolicy(iam.ManagedPolicy.fromAwsManagedPolicyName('AdministratorAccess'));
      bastaionrole.addManagedPolicy(iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonSSMManagedInstanceCore'));
      
    }
}