import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as S3Assets from 'aws-cdk-lib/aws-s3-assets';
import * as myb from './bastion-stack'

export interface Ec2L3Props {
  vpc: ec2.IVpc;  
  asset?: string;
  serverpath? : string

}

export class Ec2L3 extends Construct {
  constructor(scope: Construct, id: string, props: Ec2L3Props) {
    super(scope, id);
  
    new myb.MyBastion(this, "testBastion", props);
   new cdk.CfnOutput(this, "from module", { value: "From the module", description: "Test to see module update"});
  }
}
