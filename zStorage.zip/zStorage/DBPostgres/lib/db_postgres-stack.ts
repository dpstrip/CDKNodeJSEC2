import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as rds from 'aws-cdk-lib/aws-rds';
import * as ec2 from 'aws-cdk-lib/aws-ec2';

export class DbPostgresStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    const myVpc = ec2.Vpc.fromLookup(this, 'VPC', {vpcId:'vpc-0c10dd088ba4faa60'});

    const dbInstance = new rds.DatabaseInstance(this, 'webfocus', {
      instanceIdentifier: "webfocus",
      vpc: myVpc,
     // vpcSubnets:{
     //   subnets: ec2.SubnetType.PRIVATE_ISOLATED,
     // },
      engine: rds.DatabaseInstanceEngine.postgres({
        version: rds.PostgresEngineVersion.VER_11_14,
      }),
      instanceType: ec2.InstanceType.of(
          ec2.InstanceClass.BURSTABLE3,
          ec2.InstanceSize.MICRO,
        ),
      credentials: rds.Credentials.fromGeneratedSecret('postgres'),
      multiAz: false,
      allocatedStorage: 100,
      maxAllocatedStorage: 110,
      allowMajorVersionUpgrade: false,
      autoMinorVersionUpgrade: true,
      backupRetention: cdk.Duration.days(0),
      deleteAutomatedBackups: true,
      removalPolicy: cdk.RemovalPolicy.DESTROY,
      deletionProtection: false,
      publiclyAccessible: false ,
      databaseName: 'mydb1',   
    });

    dbInstance.addDatabase('webfocus-etcd');
  }
}
