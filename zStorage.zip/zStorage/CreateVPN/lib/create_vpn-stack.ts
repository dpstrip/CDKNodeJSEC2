import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { VpcStack }from './vpc-stack';
// import * as sqs from 'aws-cdk-lib/aws-sqs';

export class CreateVpnStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    const env = { 
      region: process.env.CDK_DEFAULT_REGION,
      account: process.env.CDK_DEFAULT_ACCOUNT
    };

    new VpcStack(this, "dpstripVpc", {env}); 
   
  }
}
